package com.shubham;

public class Contains18 {

	public static void main(String[] args) {
		String s1="JavaHariKrishna";
		System.out.println(s1.contains("a"));
		System.out.println(s1.contains("A"));
		System.out.println(s1.contains("Java"));
		System.out.println(s1.equals("Krishna"));

	}

}
