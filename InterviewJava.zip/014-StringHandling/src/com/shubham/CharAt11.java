package com.shubham;

public class CharAt11 {

	public static void main(String[] args) {
		String s1="sgbhjvdgh";
		System.out.println(s1.charAt(0));
		System.out.println(s1.charAt(1));
		System.out.println(s1.charAt(5));
		System.out.println(s1.charAt(7));
		//System.out.println(s1.charAt(-1));
		//System.out.println(s1.charAt(9));
	//	System.out.println(s1.charAt('a'));

	}

}
