package com.shubham;

public class Delete40 {

	public static void main(String[] args) {
		StringBuffer sb1=new StringBuffer("HariAmeerpet krishna");
		System.out.println(sb1);
		System.out.println();
		
		sb1.delete(4, 9);
		System.out.println(sb1);
		System.out.println();
		
		sb1.deleteCharAt(4);
		System.out.println(sb1);

	}

}
