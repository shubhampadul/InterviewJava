package com.shubham;

public class ToString {

	public static void main(String[] args) {
		String s1="Hari";
		System.out.println("s1:"+s1);
		System.out.println("s1:"+s1.toString());
		String s2=new String("Naresh IT");
		
		System.out.println("s2:"+s2);
		System.out.println("s2:"+s2.toString());
		
		String s3=null;
		System.out.println("s3:"+s3);
		System.out.println("s3:"+s3.toString());
		
		
		

	}

}
