package com.shubham;

public class SetCharAtTest39 {

	public static void main(String[] args) {
		StringBuffer sb1=new StringBuffer("ShubhaPPadul");
		System.out.println(sb1);
		System.out.println();
		
		sb1.setCharAt(6, 'm');
		System.out.println(sb1);
	}

}
