package com.shubham;

public class Reverse30 {

	public static void main(String[] args) {
		StringBuffer sb1=new StringBuffer("abc def");
		System.out.println(sb1);
		sb1.reverse();
		System.out.println("SB: char:"+sb1);

	}

}
