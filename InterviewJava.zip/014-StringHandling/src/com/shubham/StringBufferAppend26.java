package com.shubham;

public class StringBufferAppend26 {

	public static void main(String[] args) {
		StringBuffer sb=new StringBuffer("abc");
		System.out.println("SB capacity:"+sb.capacity());
		System.out.println("Length:"+sb.length());
		System.out.println(sb);
		System.out.println();
		
		sb.append("a");
		System.out.println("capacity:"+sb.capacity());
		System.out.println("Length:"+sb.length());
		System.out.println(sb);
		System.out.println();
		
		
	}

}
