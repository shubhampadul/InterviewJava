package com.shubham;

public class TrsilingFace24 {

	public static void main(String[] args) {
		String s1="abc bbc";
		System.out.println(s1);
		System.out.println();
		
		String s2=s1.trim();
		System.out.println(s1.length());
		System.out.println(s2.length());
	}

}
