package com.shubham;

public class IndexLastIndext17 {

	public static void main(String[] args) {
		String s1="Java Programing Language";
		
		System.out.println(s1.indexOf('a'));
		System.out.println(s1.lastIndexOf('a'));
		System.out.println();
		
		System.out.println(s1.indexOf('A'));
		System.out.println(s1.lastIndexOf('A'));
		System.out.println();
		
		System.out.println(s1.indexOf('a',5));
		System.out.println(s1.lastIndexOf('a',5));
		System.out.println();
		
		System.out.println(s1.indexOf("Program"));
	}

}
