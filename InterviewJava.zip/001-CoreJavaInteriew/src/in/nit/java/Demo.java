package in.nit.java;

public class Demo {
	
	public static void demoMethod()
	{
		System.out.println("method is supper");
	}
}
