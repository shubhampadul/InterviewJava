package in.nit.java;

public class Demo {
	
	public void demoMethod(int a,int b)
	{
		System.out.println(a+b);
	}
	public void demoMethod(int a,int b,int c) {
		System.out.println(a+b+c);
	}
	public static void main(String[] args) {
		Demo d=new Demo();
		d.demoMethod(10, 20);
		d.demoMethod(10,20,30);
	}
}
