package in.nit.java;

public class Demo {
	
	public void demoMethod()
	{
		System.out.println("method is supper");
	}
}
