package com.nt.java;

public interface SIM {

	public abstract void call();
	
	public abstract void sms();
	
	public default void vedioCall() {
		System.out.println("3G new Feature" );
	}
	
}
