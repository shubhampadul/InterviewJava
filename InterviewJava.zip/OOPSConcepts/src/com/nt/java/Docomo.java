package com.nt.java;

public class Docomo implements SIM {

	@Override
	public void call() {
		System.out.println("Docomo 2G sim Calling perpase");

	}

	@Override
	public void sms() {
		System.out.println("Docomo 2G Sim Functionality SMS Perperse");

	}

	

}
