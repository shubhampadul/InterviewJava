package com.nt.java;

public class MobileFactory {

	public static void main(String[] args) {
		
		Mobile redMi5=new Mobile();
		redMi5.insertSIM(new Gio());
	}

}
