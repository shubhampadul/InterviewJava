package com.nt.java;

public class Artile implements SIM {

	@Override
	public void call() {
		System.out.println("Artile 2G sim Calling perpase");

	}

	@Override
	public void sms() {
		System.out.println("Artile 2G Sim Functionality SMS Perperse");

	}

	@Override
	public void vedioCall() {
		// TODO Auto-generated method stub
		
	}

}
