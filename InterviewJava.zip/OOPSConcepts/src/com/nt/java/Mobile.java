package com.nt.java;

public class Mobile {

	public void insertSIM(SIM sim) {
		sim.call();
		sim.sms();
		sim.vedioCall();
	}
}
